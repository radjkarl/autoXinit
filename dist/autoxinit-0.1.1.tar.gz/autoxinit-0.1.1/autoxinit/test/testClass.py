# -*- coding: utf-8 -*-
class testClass:
	
	def __init__(self):
		pass